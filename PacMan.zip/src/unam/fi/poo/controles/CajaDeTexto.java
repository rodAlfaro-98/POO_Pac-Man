
package unam.fi.poo.controles;

import javafx.scene.control.TextField;

public class CajaDeTexto extends TextField {

	/**
	* @brief Constructor del objeto caja de Texto.
	*/
	public CajaDeTexto(){
		super();
		
	}
}
