
package unam.fi.poo.estructuras;

/**
* @brief Enumeracion de colores.
*/
public enum Colors{
	BLACK, GRAY, WHITE
}